$(function(){
   $('.img-thumb-box>img').click(function(){
      const src = $(this).attr('src');
      $('.img-box>img').attr('src', src);
   });
   $('.colors input[type=radio]').click(function(){
      const color = $(this).val();
      $('.selected').text(color+'색');
   })
});